# Rust Ransomware
Basic ransomware written in Rust. Works on Windows and Linux.

![Linux example](./img/linux-example.jpeg)

## Parts
This is composed of the following components:
1. Compile time key generation (the [build.rs](./build.rs) file)
2. File encrypt and encapsulate (Magic Bytes + Encrypt File Contents)
3. Ransom note dropper
4. Decrypt if valid key is found

## How the encryption works
The process is as follows for each file to encrypt:
1. Read the contents of the file as bytes
2. Check if the file begins with our "magic bytes" (the hash of the public key)
    - If it does, skip. We don't want to double encrypt.
3. Break the file down into 245 (256 minus 11) byte chunks
    - The message size cannot exceed the key size minus the padding
4. Encrypt each chunk
5. Merge our "magic bytes" and all of the encrypted chunks
6. Write the encrypted data to disk

## How the decryption works
The process is as follows for each file to decrypt:
1. Read the contents of the file as bytes
2. Check if the file begins with our "magic bytes" (the hash of the public key)
    - If it does not, skip the file. It was not encrypted.
3. Remove the "magic bytes" from the file byte array
4. Break the file down into 256 byte chunks
5. Decrypt each chunk
6. Merge the decrypted chunks
6. Write the decrypted data to disk
